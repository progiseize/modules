# Progiseize

[comment]: <> (TODO)
[comment]: <> (librairie commune)

***
### 1.2.1 (17/03/2022)
* MAJ - Prise en compte de 3 niveaux dans les numéros de version module (x.y.z)

### 1.2 (23/02/2022)
* MAJ - CSS options modules progiseize
* MAJ - Modifications des droits

### 1.1 (07/12/2021)
* NEW - Vérification des versions automatique
* NEW - Tableau de bord modules installés
* MAJ - CSS options modules progiseize