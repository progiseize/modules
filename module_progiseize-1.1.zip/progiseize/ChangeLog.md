# Progiseize

[comment]: <> (TODO)
[comment]: <> (librairie commune)

***

### 1.1 (07/12/2021)
* NEW - Vérification des versions automatique
* NEW - Tableau de bord modules installés
* MAJ - CSS options modules progiseize