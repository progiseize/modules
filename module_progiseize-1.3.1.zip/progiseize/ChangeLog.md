# Progiseize

[comment]: <> (TODO)
[comment]: <> (librairie commune)

***
### 1.3.1 (01/06/2022)
* NEW - Affichage mises à jour pages modules

### 1.3 (29/03/2022)
* MAJ - Creation d'une classe pour les objets "Modules progiseize" et transfert de la librairie vers la classe
* NEW - Ajout d'une fonction de nettoyage des variables inutilisées dans les modules

### 1.2.2 (28/03/2022)
* MAJ - Ajout Lien Assistance

### 1.2.1 (17/03/2022)
* MAJ - Prise en compte de 3 niveaux dans les numéros de version module (x.y.z)

### 1.2 (23/02/2022)
* MAJ - CSS options modules progiseize
* MAJ - Modifications des droits

### 1.1 (07/12/2021)
* NEW - Vérification des versions automatique
* NEW - Tableau de bord modules installés
* MAJ - CSS options modules progiseize